package ejercicio.concesionaria.logica;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Getter;
import lombok.Setter;


@Setter
@Getter
@Entity
public class Automovil {


    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    private long id;
    private String marca;
    private String modelo;
    private String motor;
    private String color;
    private String patente;
    private int cantPuertas;

    public Automovil() {

    }

    public Automovil(long id, String marca, String modelo, String motor, String color, String patente, int cantPuertas) {
        this.id = id;
        this.marca = marca;
        this.modelo = modelo;
        this.motor = motor;
        this.color = color;
        this.patente = patente;
        this.cantPuertas = cantPuertas;
    }

}